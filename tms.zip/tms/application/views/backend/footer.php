<!-- Footer -->
<footer class="main">
	&copy; 2014 <strong>TMSS School & College</strong>. 
    Developed by 
	<a href="http://tmss-ict.com" 
    	target="_blank">TMSS ICT</a>
</footer>
